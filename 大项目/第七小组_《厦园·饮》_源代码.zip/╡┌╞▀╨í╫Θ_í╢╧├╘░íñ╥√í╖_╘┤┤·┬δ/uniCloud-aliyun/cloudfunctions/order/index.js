'use strict';
const crypto = require('crypto')
const {getOffsetDate,getNowFormatDate} = require('time')
const db = uniCloud.database()
const _ = db.command
exports.main = async (event, context) => {
	
	// 判定 order 行为
	if(event.action == 'addTakein') {
		// 获取openId和carts
		const {
			openId,
			goodsInOrder
		} = event.data
		
		const uid = openId
		
		// 计算订单总金额
		const totalFee = goodsInOrder.reduce((acc, cur) => acc + cur.number * cur.price, 0)
		
		
		
		if(!orderResult.id) {
			return {
				code:-3,
				msg:'提交订单失败,请稍后再试'
			}
		}
			return {
				order_id
			}
		
	} else if(event.action == 'addTakeout') {
		  //获取用户openId和goodsInOrder
		        const {
		            goodsInOrder,
		            openId
		        } = event.data
		        // 关联用户openId
		        const uid = openId
		        // 计算总金额
		        const totalFee = goodsInOrder.reduce((acc, cur) => acc + cur.number * cur.price, 0) + 3
		        const order_address = event.data.order_address
		        
		        const orderResult = await db.collection('orders').add({
		            uid,
		            order_type:1, // 1- 外卖订单
		            order_id,
		            goodsInOrder,
		            totalFee,
		            order_address,
		            status: 1 // 1 - 未支付，2 - 已支付
		        })
		        
		        
		        if (!orderResult.id) {
		            return {
		                code: -3,
		                msg: '创建订单失败，请稍后再试'
		            }
		        }
		        
		        return {
		            order_id
		        }
	} else if(event.action == 'getOrder') {
		let order_id = event.order_id
		const resResult = await db.collection('orders').where({order_id}).get()
		return resResult
	} else if(event.action == 'orderCurrent') {
			let order_id = event.order_id
			//判定states状态
			const status = await db.collection('orders').where({order_id}).field({status:1})
			.get().then(res => {
				return res.data[0].status
			})
			if(status === 2) {
				
				//field封装数据
				const fields = {
								chooseStore:1,
								order_id:1,
								status:1,
								order_type:1,
								goodsInOrder:1,
								totalFee:1,
								remark:1,
								sort_num:1,
								payment_channel:1,
								createOrderTime:1,
								takeTime:1
				}
				
				//查询封装数据类型输出
				
				const resResult = await db.collection('orders').where({order_id}).field(fields)
				.get().then(res => {
					return res.data[0]
				})
				
				resResult.peopleNum = num
				
				if(updateResult.id || updateResult.updated === 1) {
					return {
						'status':0,
						'data': resResult,
						
						
						
					}
				} else {
					return {
						'status':-1,
						'msg': '后台数据错误'
					}
				}
			} else if(status === 3 || status === 4 || status === 5) {
				//field封装数据
				const fields = {
								chooseStore:1,
								order_id:1,
								status:1,
								order_type:1,
								goodsInOrder:1,
								totalFee:1,
								remark:1,
								sort_num:1,
								payment_channel:1,
								createOrderTime:1,
								takeTime:1
				}
				
				//查询封装数据类型输出
				
				const resResult = await db.collection('orders').where({order_id}).field(fields)
				.get().then(res => {
					return res.data[0]
				})
				
				return {
					'status':1,
					'data': resResult,
				}
			}
			
	} else if(event.action === 'orderUpdate') {
		let order_id = event.order_id
		//判定states状态
		const status = await db.collection('orders').where({order_id}).field({status:1})
		.get().then(res => {
			return res.data[0].status
		})
		
		return status
	}
};
